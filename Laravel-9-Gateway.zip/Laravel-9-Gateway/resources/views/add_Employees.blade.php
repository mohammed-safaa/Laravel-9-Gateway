@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Create Employee') }}</div>

                <div class="card-body">

                        <form class="form-horizontal" method="POST" action="/employee" enctype="multipart/form-data">
                            @csrf
                          <div class="form-group">
                            <label for="name" class="col-md-8 control-label">name : </label>
                            <div class="col-md-8">
                            <input type="text" class="form-control" id="text"  placeholder="Enter name" name="name" required autofocus>
                          </div>
                        </div>
                        <div class="form-group">
                          <label for="name" class="col-md-8 control-label">age: </label>
                          <div class="col-md-8">
                            <input type="text" class="form-control" id="text" placeholder="Enter age" name="age" required autofocus>
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="name" class="col-md-8 radio-inline">salary :</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" id="text"  placeholder="Enter salary" name="salary" required autofocus>
                              </div>
                            </div>
                          <div class="form-group">
                            <label for="sel1" class="col-md-8 control-label">gender : </label>
                            <div class="col-md-8">
                              <select type="text" class="form-control"  name="gender" id="sel1" required autofocus>

                              <option>male</option>
                              <option>female</option>
                            </select>
                          </div>
                        </div>

                        <div class="form-group">
                            <label for="sel1" class="col-md-8 control-label">hired date : </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" id="text"  placeholder="Enter hired date"  name="hired_date" required autofocus>
                          </div>
                        </div>

                        <div class="form-group">
                          <label for="sel1" class="col-md-8 control-label">job title: </label>
                          <div class="col-md-8">
                            <select type="text" class="form-control"  name="job_title" id="sel1" required autofocus>
                              <option>fonder</option>
                              <option>manager</option>
                              <option>employee</option>
                          </select>
                        </div>
                      </div>
                      <br>

                            <div class="form-group">
                              <div class="col-md-8 col-md-offset-4">
                                <meta name="csrf-token" content="{{ csrf_token() }}">
                                <button type="submit" class="btn btn-warning btn-sm"> Add </button>
                              </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection
