<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <!-- Scripts -->
    {{-- @vite(['resources/sass/app.scss', 'resources/js/app.js']) --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <style>
body{
    font-family: 'Poppins', sans-serif;
}
        .jtable{width:100%;overflow-x:hidden}.jtable__table{overflow-x:auto}.jtable > .jtable__panel{width:100%;margin:.5em 0;display:flex;align-items:center}.jtable > .jtable__panel > div{display:flex;flex-direction:column;justify-content:center}.jtable > .jtable__panel > div:first-child{width:10%;flex-direction:row;align-items:center}.jtable > .jtable__panel > div:first-child > span{width:75%;margin-left:.5rem}.jtable > .jtable__panel > div:last-child{width:50%;margin-left:auto;align-items:flex-end}.jtable .jtable__search,.jtable .jtable__select{font-size:1rem;position:relative;width:100%;font-family:inherit;border-radius:.25em;border:solid .01em #d0d0d0;padding-inline-start:0;padding:.5em 1em}.jtable table{border:solid .01em #d0d0d0;border-radius:.25em;background-color:white;border-spacing:0;table-layout:fixed;margin-top:.5em;width:100%;overflow-x:auto}.jtable table > tbody > tr:nth-child(2n){background-color:rgba(0,0,0,.05)}.jtable table tr > th,.jtable table tr > td{padding:.5em 1em;text-align:left;border-bottom:solid .01em #d0d0d0;border-right:solid .01em #d0d0d0}.jtable table tr:last-child > td{border-bottom:none}.jtable table tr > th:last-child,.jtable table tr > td:last-child{border-right:none}.jtable table > thead th{cursor:pointer}.jtable table > thead th[aria-sort=ascending]{background-image:url("../img/sort-asc.svg");background-position:right 1em top .75em;background-repeat:no-repeat;background-size:1em}.jtable table > thead th[aria-sort=descending]{background-image:url("../img/sort-desc.svg");background-position:right 1em top .75em;background-repeat:no-repeat;background-size:1em}.jtable__pagination{display:flex;align-items:center}.jtable__pagination > button{height:2rem;min-width:2rem;margin:0 .25em;text-align:center;border-radius:0.25em;border:solid .01em #d0d0d0;cursor:pointer;padding:.5em;font-size:1em}.jtable__pagination > button:first-child{margin-left:0}.jtable__pagination > button.btn-char{font-size:.75em}.jtable__pagination > button[aria-selected=true]{background-color:#d0d0d0;border-color:#b0b0b0}.jtable__pagination > button:last-child{margin-right:0}@media screen and (max-width: 720px){.jtable > .jtable__panel{flex-direction:column}.jtable > .jtable__panel > div{align-items:flex-start !important;width:100% !important}.jtable > .jtable__panel > div:first-child{margin-bottom:.5em}.jtable table{table-layout:initial}}
    </style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'Laravel') }}
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">



                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        @guest
                            @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else

                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="/home">Home</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" href="{{ route('employee.index') }}">Employees</a>
                          </li>

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }}
                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>


    <script>

window.DT_LOCALES={},window.DT_LOCALES.it={SEARCH:"cerca",PER_PAGE:"righe per pagina",SHOWING_TO:"righe da {FROM} a {TO} di {SIZE}",GOTO_FIRST:"vai a pagina 1",GOTO_PREV:"vai a pagina precedente",GOTO_PAGE:"vai a pagina {NUM}",GOTO_NEXT:"vai a pagina successiva",GOTO_LAST:"vai all'ultima pagina",ASC_ACTIVE:"ordine crescente attivo",DESC_ACTIVE:"ordine decrescente attivo",NOT_ACTIVE:"non attivo",NO_RESULT:"nessun risultato"},window.DT_LOCALES.en={SEARCH:"search",PER_PAGE:"rows per page",SHOWING_TO:"rows {FROM} to {TO} of {SIZE}",GOTO_FIRST:"go to page 1",GOTO_PREV:"go to previous page",GOTO_PAGE:"go to page {NUM}",GOTO_NEXT:"go to next page",GOTO_LAST:"go to last page",ASC_ACTIVE:"ascending order active",DESC_ACTIVE:"descending order active",NOT_ACTIVE:"not active",NO_RESULT:"no result"};const DT_LOCALES=window.DT_LOCALES,DT_PREFIX="jtable",DT_TRIGGER=`[data-replace='${DT_PREFIX}']`;class DataTable{constructor(e){this.el=e,this.data=[],this.filtered=[],this.currPage=1,this.perPage=10,this.locale={}}checkId(){this.el.hasAttribute("id")&&0!=this.el.id.length||(this.el.id=`${DT_PREFIX}-${+new Date}`)}getPgMessage(){let e=(this.currPage-1)*this.perPage+1,t=e+(this.el.querySelectorAll("tbody tr").length-1);document.querySelector(`#${this.el.id}_pgdisplay`).innerHTML=this.locale.SHOWING_TO.replace("{FROM}",e).replace("{TO}",t).replace("{SIZE}",this.filtered.length)}getData(){let e=[],t=[];return this.el.querySelectorAll("thead th").forEach(e=>t.push(e.innerHTML)),this.el.querySelectorAll("tbody > tr").forEach(i=>{let a={};i.querySelectorAll("td").forEach((e,i)=>a[t[i]]=e.innerHTML),e.push(a)}),e}printData(e){let t=this.el.querySelector("tbody");t.innerHTML="",e.forEach(e=>{let i=document.createElement("tr");Object.keys(e).forEach(t=>{let a=document.createElement("td");a.innerHTML=e[t],i.appendChild(a)}),t.appendChild(i)})}changePage(e){let t=this.perPage*(e-1),i=t+this.perPage,a=this.filtered.slice(t,i);this.currPage=e,this.printData(a),this.getPgMessage(),this.pagination()}search(e){if(e=e.toLowerCase().trim(),this.filtered=this.data.filter(t=>{let i=!1;for(let a in t)i=i||t[a].toLowerCase().includes(e);return i}),this.currPage=1,0==this.filtered.length){let e=Object.keys(this.data[0]),t=document.createElement("tr"),i=document.createElement("td");i.setAttribute("aria-live","polite"),i.innerHTML=this.locale.NO_RESULT,i.style.textAlign="center",i.colSpan=e.length,t.appendChild(i),this.el.querySelector("tbody").innerHTML="",this.el.querySelector("tbody").appendChild(t)}else this.printData(this.filtered.slice(0,this.perPage));this.pagination(),this.getPgMessage()}pagination(){let e=document.createElement("div");e.classList.add(`${DT_PREFIX}__pagination`);let t=Math.ceil(this.filtered.length/this.perPage);if(this.currPage>1){let t=document.createElement("button");t.setAttribute("aria-controls",this.el.id),t.setAttribute("aria-label",this.locale.GOTO_FIRST),t.innerHTML="&#10094;&#10094;",t.classList.add("btn-char"),t.onclick=(()=>this.changePage(1)),e.appendChild(t);let i=document.createElement("button");i.setAttribute("aria-controls",this.el.id),i.setAttribute("aria-label",this.locale.GOTO_PREV),i.innerHTML="&#10094;",i.classList.add("btn-char"),i.onclick=(()=>this.changePage(this.currPage-1)),e.appendChild(i)}for(let i=this.currPage-2;i<this.currPage+2;i++){if(i<1||i>t)continue;let a=document.createElement("button");a.setAttribute("aria-controls",this.el.id),a.setAttribute("aria-label",this.locale.GOTO_PAGE.replace("{NUM}",i)),a.classList.add("btn"),a.innerHTML=i,i==this.currPage?a.setAttribute("aria-selected",!0):a.onclick=(()=>this.changePage(i)),e.appendChild(a)}if(this.currPage<t){let i=document.createElement("button");i.setAttribute("aria-controls",this.el.id),i.setAttribute("aria-label",this.locale.GOTO_NEXT),i.innerHTML="&#10095;",i.classList.add("btn-char"),i.onclick=(()=>this.changePage(this.currPage+1)),e.appendChild(i);let a=document.createElement("button");a.setAttribute("aria-controls",this.el.id),a.setAttribute("aria-label",this.locale.GOTO_LAST),a.innerHTML="&#10095;&#10095;",a.classList.add("btn-char"),a.onclick=(()=>this.changePage(t)),e.appendChild(a)}document.querySelector(`#${this.el.id}_pagination`).innerHTML="",document.querySelector(`#${this.el.id}_pagination`).appendChild(e)}changeOrder(e,t){let i=this.perPage*(this.currPage-1),a=this.filtered.length>this.perPage?i+this.perPage:this.filtered.length,l=this.filtered.sort((i,a)=>i[e]>a[e]?t:-t);this.printData(l.slice(i,a))}toggleHead(e,t){let i=t.getAttribute("aria-sort")||"";e.forEach(e=>{e.removeAttribute("aria-sort"),e.setAttribute("aria-label",`${e.innerText}: non attivo`)}),0==i.length||"d"==i[0]?(t.setAttribute("aria-sort","ascending"),t.setAttribute("aria-label",`${t.innerText}: ${this.locale.ASC_ACTIVE}`),this.changeOrder(t.innerText,1)):(t.setAttribute("aria-sort","descending"),t.setAttribute("aria-label",`${t.innerText}: ${this.locale.DESC_ACTIVE}`),this.changeOrder(t.innerText,-1))}init(){this.data=this.getData(),this.filtered=this.data,this.hasSearch=this.el.dataset.search,this.locale=DT_LOCALES[this.el.dataset.locale],this.checkId(),this.printData(this.filtered.slice(0,this.perPage));let e=document.createElement("div");e.classList.add(DT_PREFIX);let t=document.createElement("div");t.classList.add(`${DT_PREFIX}__panel`);let i=document.createElement("div"),a=document.createElement("select");a.classList.add(`${DT_PREFIX}__select`);let l=document.createElement("span");l.innerHTML=this.locale.PER_PAGE;for(let e=1;e<=5;e++)a.innerHTML+=`<option ${1==e?"selected":""} value='${10*e}'>\n                    ${10*e}\n                </option>`;if(a.onchange=(()=>{this.perPage=parseInt(a.value),this.changePage(1)}),i.appendChild(a),i.appendChild(l),t.appendChild(i),this.hasSearch){let e=document.createElement("div"),i=document.createElement("input");i.setAttribute("aria-controls",this.el.id),i.classList.add(`${DT_PREFIX}__search`),i.setAttribute("role","searchbox"),i.placeholder=this.locale.SEARCH,i.classList.add("control"),i.type="search",i.addEventListener("input",()=>this.search(i.value)),e.appendChild(i),t.appendChild(e)}e.appendChild(t);let r=this.el.querySelectorAll("thead th");r.forEach(e=>{e.setAttribute("tabindex",0),e.setAttribute("scope","col"),e.setAttribute("aria-controls",this.el.id),e.setAttribute("aria-label",`${e.innerText}: ${this.locale.NOT_ACTIVE}`),e.addEventListener("click",()=>this.toggleHead(r,e)),e.addEventListener("keyup",t=>{document.activeElement==e&&"Enter"==t.key&&this.toggleHead(r,e)})});let s=document.createElement("div");s.classList.add(`${DT_PREFIX}__table`),this.el.parentElement.insertBefore(e,this.el),e.appendChild(s),s.appendChild(this.el);let n=document.createElement("div");n.classList.add(`${DT_PREFIX}__panel`);let c=document.createElement("div");c.setAttribute("aria-live","polite"),c.id=`${this.el.id}_pgdisplay`,n.appendChild(c);let d=document.createElement("div");d.id=`${this.el.id}_pagination`,n.appendChild(d),e.appendChild(n),this.pagination(),this.getPgMessage(),this.el.removeAttribute("data-search"),this.el.removeAttribute("data-locale"),this.el.removeAttribute("data-replace")}}document.querySelectorAll(DT_TRIGGER).forEach(e=>new DataTable(e).init());



    </script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
