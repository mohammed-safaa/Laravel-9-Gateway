@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Edit Employee') }}</div>

                <div class="card-body">

                    <form class="form-horizontal" method="POST" action="{{ htmlspecialchars(route('employee.update',$employee_id->id)) }}" enctype="multipart/form-data">
                        {{ method_field('PUT') }}
                        {{ csrf_field() }}
                          <div class="form-group">
                            <label for="name" class="col-md-8 control-label">name : </label>
                            <div class="col-md-8">
                            <input type="text" class="form-control" id="text" value="{{ $employee_id->name }}" placeholder="Enter name" name="name" required autofocus>
                          </div>
                        </div>
                        <div class="form-group">
                          <label for="name" class="col-md-8 control-label">age: </label>
                          <div class="col-md-8">
                            <input type="text" class="form-control" id="text" value="{{ $employee_id->age }}" placeholder="Enter age" name="age" required autofocus>
                            </div>
                          </div>

                          <div class="form-group">
                            <label for="name" class="col-md-8 radio-inline">salary :</label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" id="text" value="{{ $employee_id->salary }}" placeholder="Enter salary" name="salary" required autofocus>
                              </div>
                            </div>
                          <div class="form-group">
                            <label for="sel1" class="col-md-8 control-label">gender : </label>
                            <div class="col-md-8">
                              <select type="text" class="form-control" value="{{ $employee_id->gender }}"  name="gender" id="sel1" required autofocus>
                                <option>{{ $employee_id->gender }}</option>
                              <option>male</option>
                              <option>female</option>
                            </select>
                          </div>
                        </div>

                        <div class="form-group">
                            <label for="sel1" class="col-md-8 control-label">hired date : </label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" id="text"  placeholder="Enter hired date" value="{{ $employee_id->hired_date }}" name="hired_date" required autofocus>
                          </div>
                        </div>

                        <div class="form-group">
                          <label for="sel1" class="col-md-8 control-label">job title: </label>
                          <div class="col-md-8">
                            <select type="text" class="form-control" value="{{ $employee_id->job_title }}" name="job_title" id="sel1" required autofocus>
                              <option>{{ $employee_id->job_title }}</option>
                              <option>fonder</option>
                              <option>manager</option>
                              <option>employee</option>
                          </select>
                        </div>
                      </div>
                      <br>

                            <div class="form-group">
                              <div class="col-md-8 col-md-offset-4">
                                  <button type="submit" class="btn btn-warning">
                                      Update
                                  </button>
                              </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>


                </div>
            </div>
        </div>
    </div>
</div>
@endsection
