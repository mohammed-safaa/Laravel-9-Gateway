@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <a href="{{ route('employee.create') }}" class="btn btn-warning btn-sm" role="button">Create Employee</a>

            <a class="btn btn-warning btn-sm" href="{{ route('users.export') }}">Export User Data</a>
            <br>  <br>
            <div class="card">
                <div class="card-header">{{ __('Employees') }}  </div>
                <div class="card-body">
                    <table class="table table-sm" data-replace="jtable" id="example" aria-label="JS Datatable" data-locale="en" data-search="true">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Salary</th>
                                <th>Gender</th>
                                <th>Hired date</th>
                                <th>Job title</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($allEmployee as $item)
                            <tr>

                                <td><a href="{{route('employee.show', $item->id)}}">{{ $item->name }}</a></td>
                                <td>{{ $item->age }}</td>
                                <td>{{ $item->salary }}</td>
                                <td>{{ $item->gender }}</td>
                                <td>{{ $item->hired_date }}</td>
                                <td>{{ $item->job_title }}</td>
                                <td>
                                    <a href="{{ route('employee.edit',$item->id ) }}" class="btn btn-warning btn-sm" role="button">EDIT</a>
                                </td>
                                <td>
                                    <form action="{{ route('employee.destroy',$item->id) }}" method="POST">
                                        {{ csrf_field() }}

                                        {{method_field('DELETE')}}

                                        <button class="btn btn-danger btn-sm" type="submit" aria-label="">DELETE</button>
                                    </form>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
