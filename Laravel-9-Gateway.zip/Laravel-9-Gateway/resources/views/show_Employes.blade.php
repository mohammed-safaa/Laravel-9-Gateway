@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ __('Employee') }}</div>

                <div class="card-body">
                    <div class="card" style="width: 20rem;">
                        <div class="card-body">
                          <h5 class="card-title">Name : {{ $employes->name }}</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Age : {{ $employes->age }}</h6>
                          <p class="card-text">Salary : {{ $employes->salary }}</p>
                          <p class="card-text">Hired date : {{ $employes->hired_date }}</p>
                          <p class="card-text">Job title : {{ $employes->job_title }}</p>
                        </div>
                      </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
