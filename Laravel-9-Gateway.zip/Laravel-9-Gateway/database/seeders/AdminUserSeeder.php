<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\API\Employee;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

       // run ->   php artisan db:seed //
       // Generate a number of employees


       $x = 1;
       while($x <= 1000) {
        Employee::create([
            'name' => 'mohammed_safaa'.(rand(1000,10000)),
            'age' => '33',
            'salary' => '$1200',
            'gender' => 'male',
            'hired date' => '01-04-2023',
            'job title' => 'Developer',
            // 'email' => 'mohammed_safaa'.(rand(1000,10000)).'@gmail.com',
            // 'password' => bcrypt('12345678'),
        ]);
         $x++;
       }






    }
}
