<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\ExportController;
use Illuminate\Mail\Message;
use Illuminate\Support\Facades\DB;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::resource('/employee', EmployeeController::class);


Route::controller(UserController::class)->group(function(){
    Route::get('users', 'index');
    Route::get('users-export', 'export')->name('users.export');
    Route::post('users-import', 'import')->name('users.import');
});


Route::get('sendemail', function () {

    Mail::send('emails.welcome', $data, function ($message) {
        $message->from('mohammed.safaa.alzobie@gmail.com', 'hi ');
        $message->to('sender.baghdad.techno.ltd@gmail.com')->subject('hi ');
    });
    return redirect(url('/home'));
});
