<?php

namespace App\Http\Controllers;

use App\Models\API\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{

    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function index()
    {
        $allEmployee = Employee::orderBy('id', 'DESC')->get();
        return view('Employees')->with('allEmployee',$allEmployee);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('add_Employees');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
                         // THIS ADD POST
    $this->validate($request,[
        'name'=>'required|string|max:255',
        'age'=>'required|string|max:2',
        'salary'=>'required|string|max:20',
        'gender'=>'required|string|max:100',
        'hired_date'=>'required|string|max:500',
        'job_title'=>'required|string|max:500',
    ]);

    $post = new Employee;
    $post->name = $request->name;
    $post->age = $request->age;
    $post->salary = $request->salary;
    $post->gender = $request->gender;
    $post->hired_date = $request->hired_date;
    $post->job_title = $request->job_title;
    $post->save();

    return redirect(url('home'));



    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\API\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //show_Employess

        $employes = Employee::find($id);
        return view('show_Employes', compact('employes','employes'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\API\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $employee_id = Employee::find($id);
        return view('edit_Employees')->with('employee_id',$employee_id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\API\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
                 // THIS UPDATE POST
                 $this->validate($request,[
                    'name'=>'required|string|max:255',
                    'age'=>'required|string|max:2',
                    'salary'=>'required|string|max:20',
                    'gender'=>'required|string|max:100',
                    'hired_date'=>'required|string|max:500',
                    'job_title'=>'required|string|max:500',
                ]);

                $nes = Employee::find($id);
                $nes->name = $request->input('name');
                $nes->age = $request->input('age');
                $nes->salary = $request->input('salary');
                $nes->gender = $request->input('gender');
                $nes->hired_date = $request->input('hired_date');
                $nes->job_title = $request->input('job_title');
                $nes->save();

                return redirect(url('employee'));

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\API\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $employeedel = Employee::find($id);
        $employeedel->destroy($id);
        return redirect(url('/employee'));

    }
}
