<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">

                <h1 class="text-center" style="font-size: 130px; padding: 50px;}">WELCOME</h1>
               <h1 class="text-center" style="padding: 10px;">HR.Management</h1>

          

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohammed/Downloads/Laravel-9-Gateway/resources/views/home.blade.php ENDPATH**/ ?>