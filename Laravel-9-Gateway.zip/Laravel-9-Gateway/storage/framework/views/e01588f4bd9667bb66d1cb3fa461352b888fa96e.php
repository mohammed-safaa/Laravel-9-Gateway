<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Employees')); ?></div>

                <div class="card-body">
                    <table class="table table-sm" data-replace="jtable" id="example" aria-label="JS Datatable" data-locale="en" data-search="true">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Salary</th>
                                <th>Gender</th>
                                <th>Hired date</th>
                                <th>Job title</th>
                                <th>Manager</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>mohammed</td>
                                <td>38</td>
                                <td>3000$</td>
                                <td>male</td>
                                <td>25-5-2022</td>
                                <td>it</td>
                                <td>ahmed</td>
                                <td><button type="button" class="btn btn-outline-warning  btn-sm">EDIT</button></td>
                                <td><button type="button" class="btn btn-outline-danger  btn-sm">DELETE</button></td>
                            </tr>

                            <tr>
                                <td>mohammed</td>
                                <td>38</td>
                                <td>3000$</td>
                                <td>male</td>
                                <td>25-5-2022</td>
                                <td>it</td>
                                <td>ahmed</td>
                                <td><button type="button" class="btn btn-outline-warning  btn-sm">EDIT</button></td>
                                <td><button type="button" class="btn btn-outline-danger  btn-sm">DELETE</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohammed/Downloads/Laravel-9-REST-API-with-Passport-master/resources/views/home.blade.php ENDPATH**/ ?>