<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Employee')); ?></div>

                <div class="card-body">
                    <div class="card" style="width: 20rem;">
                        <div class="card-body">
                          <h5 class="card-title">Name : <?php echo e($employes->name); ?></h5>
                          <h6 class="card-subtitle mb-2 text-muted">Age : <?php echo e($employes->age); ?></h6>
                          <p class="card-text">Salary : <?php echo e($employes->salary); ?></p>
                          <p class="card-text">Hired date : <?php echo e($employes->hired_date); ?></p>
                          <p class="card-text">Job title : <?php echo e($employes->job_title); ?></p>
                        </div>
                      </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohammed/Downloads/Laravel-9-Gateway/resources/views/show_Employes.blade.php ENDPATH**/ ?>