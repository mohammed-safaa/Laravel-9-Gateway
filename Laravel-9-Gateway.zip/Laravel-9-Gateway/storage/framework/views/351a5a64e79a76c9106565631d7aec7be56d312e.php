<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-warning btn-sm" role="button">Create Employee</a>

            <a class="btn btn-warning btn-sm" href="<?php echo e(route('users.export')); ?>">Export User Data</a>
            <br>  <br>
            <div class="card">
                <div class="card-header"><?php echo e(__('Employees')); ?>  </div>
                <div class="card-body">
                    <table class="table table-sm" data-replace="jtable" id="example" aria-label="JS Datatable" data-locale="en" data-search="true">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Salary</th>
                                <th>Gender</th>
                                <th>Hired date</th>
                                <th>Job title</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $allEmployee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>

                                <td><a href="<?php echo e(route('employee.show', $item->id)); ?>"><?php echo e($item->name); ?></a></td>
                                <td><?php echo e($item->age); ?></td>
                                <td><?php echo e($item->salary); ?></td>
                                <td><?php echo e($item->gender); ?></td>
                                <td><?php echo e($item->hired_date); ?></td>
                                <td><?php echo e($item->job_title); ?></td>
                                <td>
                                    <a href="<?php echo e(route('employee.edit',$item->id )); ?>" class="btn btn-warning btn-sm" role="button">EDIT</a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('employee.destroy',$item->id)); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>


                                        <?php echo e(method_field('DELETE')); ?>


                                        <button class="btn btn-danger btn-sm" type="submit" aria-label="">DELETE</button>
                                    </form>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mohammed/Downloads/Laravel-9-Gateway/resources/views/Employees.blade.php ENDPATH**/ ?>